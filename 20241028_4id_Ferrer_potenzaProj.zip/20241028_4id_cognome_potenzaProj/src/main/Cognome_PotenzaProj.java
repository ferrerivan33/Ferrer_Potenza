
package main;

import logic.Potenza;

import java.util.Scanner;

public class Cognome_PotenzaProj {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Inserisci la base: ");
        int base = scanner.nextInt();

        System.out.print("Inserisci l'esponente: ");
        int esponente = scanner.nextInt();

        // Usa il metodo della classe Potenza
        int risultato = Potenza.calcola(base, esponente);

        System.out.println("Risultato: " + risultato);
    }
}
