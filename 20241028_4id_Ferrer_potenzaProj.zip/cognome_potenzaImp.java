
import java.util.Scanner;

public class Cognome_PotenzaImp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Inserisci la base: ");
        int base = scanner.nextInt();

        System.out.print("Inserisci l'esponente: ");
        int esponente = scanner.nextInt();

        int risultato = 1; // Inizializza il risultato
        for (int i = 0; i < esponente; i++) {
            risultato *= base; // Moltiplica per la base
        }

        System.out.println("Risultato: " + risultato);
    }
}
